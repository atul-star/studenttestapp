from .import db

class Repodata(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    issueid=db.Column(db.Integer)
    userid=db.Column(db.Integer)
    username=db.Column(db.String(100))
    title=db.Column(db.String(200))
    state=db.Column(db.String(50))
    created_at=db.Column(db.DateTime)
    closed_at=db.Column(db.DateTime)
    #body=db.Column(db.Text())
    labels=db.relationship("Label",backref='reporef')

class Label(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    labelid=db.Column(db.Integer)
    labelname=db.Column(db.String(50))
    issueid=db.Column(db.ForeignKey('repodata.id'))
