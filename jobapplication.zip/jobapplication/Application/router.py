from flask import render_template,request,session
import requests
import datetime
from datetime import date,timedelta
from sqlalchemy import and_,desc
from .models import *
from flask import current_app as app


def getdata():
    issuesdata=Repodata.query.all()
    return issuesdata


@app.route("/",methods=['GET'])
def index():
    return render_template("login.html")

@app.route("/login",methods=['POST'])
def login():
    username=request.form['username']
    password=request.form['password']
    # print(request.form['username'])
    # print(request.form['password'])

    res=requests.get('https://api.github.com/user',auth=(username,password))
    if res.status_code==200:
        session['username']=request.form['username']
        if res.status_code==200:
            result=res.json()
            repos=result['repos_url']

            closedissues='https://api.github.com/repos/chartjs/chartjs-plugin-datalabels/issues?state=closed'
            openissues='https://api.github.com/repos/chartjs/chartjs-plugin-datalabels/issues?state=open'
            repo_res=requests.get(closedissues)
            repo_res_open=requests.get(openissues)
            repo_result=repo_res.json()
            repo_result_open=repo_res_open.json()
            repo_result.extend(repo_result_open)


            for l in repo_result:
                issueid=l['id']
                userid=l['user']['id']
                username=l['user']['login']
                title=l['title']
                state=l['state']
                created_at=l['created_at']
                created_at=created_at[0:10]
                created_date=datetime.datetime.strptime(created_at, '%Y-%m-%d').date()
                closed_at=l['closed_at']
                if state=='closed':
                    closed_at = closed_at[0:10]
                    closed_date = datetime.datetime.strptime(closed_at, '%Y-%m-%d').date()
                else:
                    closed_date=None
                body=l['body']

                rep_obj=Repodata(issueid=issueid,userid=userid,username=username,title=title,state=state,created_at=created_date,closed_at=closed_date)

                db.session.add(rep_obj)
                db.session.commit()
                labels=l['labels']

                for lb in labels:
                    labelobj=Label(labelid=lb['id'],labelname=lb['name'],issueid=rep_obj.id)

                    db.session.add(labelobj)
                    db.session.commit()

        issuedatalist=getdata()

        return render_template("home.html",issuedatalist=issuedatalist,sessiondata=session['username'])
    else:
        return render_template("login.html", sessiondata="Please provide valid credentials")



@app.route("/labelsdata",methods=['POST'])
def labelsdata():
    label=request.form['label']
    x=request.form['xday']


    if x=="":
        listofissuestodisplay=[]
        listofissues=[]
        listoflabelobjs=Label.query.filter(Label.labelname==label).all()
        for lb in listoflabelobjs:
            listofissues.append(lb.issueid)
        for issue in listofissues:
            issueobj=Repodata.query.filter(Repodata.id==issue).first()
            listofissuestodisplay.append(issueobj)
    else:


        latestDate = db.session.query(Repodata).order_by(desc('created_at')).first()

        dateBefore = (latestDate.created_at) - timedelta(days=int(x))

        listofissuestodisplay = Repodata.query.filter(
            and_(Repodata.created_at >= dateBefore, Repodata.created_at <= latestDate.created_at)).all()

        return render_template("home.html", issuedatalist=listofissuestodisplay,sessiondata=session['username'])


    return render_template("home.html",issuedatalist=listofissuestodisplay,sessiondata=session['username'])

@app.route("/user/<int:id>")
def userdata(id):
    # import pdb
    # pdb.set_trace()

    userdata=Repodata.query.filter(Repodata.userid==id).all()

    return render_template("home.html",issuedatalist=userdata,sessiondata=session['username'])


@app.route('/logout')
def sign_out():
    session.pop('username')

    return render_template("login.html")
